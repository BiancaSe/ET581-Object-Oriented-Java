// ET 581 Homework 8, Problem 2, Student : Bianca Serpe Date 11/03/2025
package qcc;

//Interface Playable to define playable behavior
public interface Playable { 
    void play(); // Method to play the object
    void pause(); // Method to pause the object
    void stop(); // Method to stop the object

}
